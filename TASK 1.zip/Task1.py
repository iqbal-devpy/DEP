import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# Load dataset
df = pd.read_csv('D/UNIVERSITY/1 semester/programming/python test codes/DEP Internship/Entities.xlsx')

# Display the first few rows of the dataframe
print(df.head())

# Data Cleaning and Preprocessing
# Handle missing values (example: fill with median)
df.fillna(df.median(), inplace=True)

# Convert categorical variables (example: one-hot encoding)
categorical_features = ['property_type', 'location', 'city', 'province_name', 'purpose']
numerical_features = ['latitude', 'longitude', 'baths', 'bedrooms', 'Total_Area']

preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_features),
        ('cat', OneHotEncoder(), categorical_features)])

# Define the model
model = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', LinearRegression())
])

# Split data into training and testing sets
X = df.drop(['price', 'property_id', 'location_id', 'page_url', 'date_added', 'agency', 'agent'], axis=1)
y = df['price']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
model.fit(X_train, y_train)

# Predict on test data
y_pred = model.predict(X_test)

# Evaluate the model
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f'MAE: {mae}')
print(f'MSE: {mse}')
print(f'R-squared: {r2}')
